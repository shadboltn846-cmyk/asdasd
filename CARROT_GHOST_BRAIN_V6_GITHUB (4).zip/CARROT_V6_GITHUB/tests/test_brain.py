import sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from brain.core import load_day,encode,ghost_surface,PatternBrain,run_day,LOCKED,ACTIONS
from engine.gold_auction_response_v4_hot250_cold_recovery import generate_candidates,compute_features,simulate_v4_day,eastern_score_bounds

def test_firewall():
 for d in LOCKED:
  try:load_day(ROOT/'data'/'5s_features'/f'{d}_5s_features.csv')
  except PermissionError:pass
  else:raise AssertionError('Holdout firewall bypassed '+d)
 files=list((ROOT/'data'/'5s_features').glob('*.csv'))
 assert len(files)==20 and all(p.name[:10] not in LOCKED for p in files)
 print('PASS 20 development dates and 7 locked dates blocked')

def test_ghost_invariants():
 date,d=load_day(ROOT/'data'/'5s_features'/'2026-04-15_5s_features.csv')
 features=encode(d);assert len(features)==len(d) and features.shape[1]>45
 t=ghost_surface(d,3.)
 assert len(t)==8 and all(len(x.reward)==len(d) for x in t)
 for a,(side,name,tp,sl,h,stride) in enumerate(ACTIONS):
  assert np.isnan(t[a].reward[-h:]).all(),(a,'future not matured')
  ix=np.flatnonzero(t[a].reason==1)
  if len(ix):assert np.max(np.abs(t[a].reward[ix]-(-sl-3)))<1e-5
  valid=np.flatnonzero(t[a].exit_i>=0)
  assert np.all(t[a].exit_i[valid]>valid)
 print('PASS ghost BUY/SELL × 4 plans; maturity, conservative SL and durations')

def test_no_future_leak():
 date,d=load_day(ROOT/'data'/'5s_features'/'2026-04-13_5s_features.csv')
 # Alter ONLY future; earlier features and decisions cannot change.
 changed=d.copy();j=6000
 changed.loc[j:,'x_open']+=30;changed.loc[j:,'x_high']+=30
 changed.loc[j:,'x_low']+=30;changed.loc[j:,'x_close']+=30
 xa=encode(d);xb=encode(changed)
 assert np.allclose(xa[:j],xb[:j]),'Future affects pre-entry feature'
 b1=PatternBrain(xa.shape[1]);b2=PatternBrain(xa.shape[1]);
 out1,t1,dec1=run_day(b1,d,date,max_decisions=3000)
 out2,t2,dec2=run_day(b2,changed,date,max_decisions=3000)
 cut=int(d.ts.iat[j-1200])
 a=dec1[dec1.signal_ts<cut].reset_index(drop=True)
 b=dec2[dec2.signal_ts<cut].reset_index(drop=True)
 for k in ['signal_ts','action','model_score','pattern_id','novelty','drift']:
  assert a[k].equals(b[k]),('future leakage',k)
 print('PASS future-price perturbation cannot alter earlier model decisions')

def test_no_overlap():
 date,d=load_day(ROOT/'data'/'5s_features'/'2026-04-13_5s_features.csv')
 m=PatternBrain(encode(d).shape[1]);_,tr,_=run_day(m,d,date)
 if len(tr)>1:assert np.all(tr.entry_ts.iloc[1:].to_numpy()>=tr.exit_ts.iloc[:-1].to_numpy())
 print('PASS paper positions non-overlapping; no broker order execution')

if __name__=='__main__':
 test_firewall();test_ghost_invariants();test_no_future_leak();test_no_overlap()
 print('ALL TESTS PASS')
