"""V6 development-only causal, serialization and isolation invariants."""
import sys
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from brain.core import LOCKED,load_day,encode,ghost_surface,ACTIONS
from brain.v6 import GhostResearchBrain,run_v6_day

def test_locked():
    files=sorted((ROOT/'data'/'5s_features').glob('*_5s_features.csv'))
    assert len(files)==20 and all(f.name[:10] not in LOCKED for f in files)
    for date in LOCKED:
        try:load_day(ROOT/'data'/'5s_features'/f'{date}_5s_features.csv')
        except PermissionError:pass
        else:raise AssertionError('Locked day was not rejected: '+date)
    print('PASS V6 locked seven-date firewall and exactly 20 development files')

def test_maturity_and_resume():
    _,d=load_day(ROOT/'data'/'5s_features'/'2026-04-13_5s_features.csv')
    x=encode(d);T=ghost_surface(d,3)
    assert len(T)==8
    for a,(_side,_name,_tp,_sl,h,_s) in enumerate(ACTIONS):
        assert np.isnan(T[a].reward[-h:]).all()
    model=GhostResearchBrain(x.shape[1])
    model.observe(0,x[180],-23, int(d.ts.iat[200]),0,-10)
    before=[model.forecast(a,x[300],int(d.ts.iat[300])) for a in range(8)]
    state=json.loads(json.dumps(model.state()))
    restored=GhostResearchBrain.restore(state)
    after=[restored.forecast(a,x[300],int(d.ts.iat[300])) for a in range(8)]
    assert before==after
    assert restored.total_labels==model.total_labels
    assert abs(restored.fc_err[0]-(-13))<1e-8
    print('PASS V6 ghost maturity and JSON model memory round-trip')

def test_causal_future_and_paper():
    date,d=load_day(ROOT/'data'/'5s_features'/'2026-04-15_5s_features.csv')
    changed=d.copy();j=6500
    for key in ('x_open','x_high','x_low','x_close'):
        changed.loc[j:,key]+=23
    assert np.allclose(encode(d)[:j],encode(changed)[:j])
    br1=GhostResearchBrain(encode(d).shape[1]);br2=GhostResearchBrain(encode(d).shape[1])
    _,tr1,de1=run_v6_day(br1,d,date,0,max_decisions=1400)
    _,tr2,de2=run_v6_day(br2,changed,date,0,max_decisions=1400)
    boundary=int(d.ts.iat[j-1100])
    a=de1[de1.signal_ts<boundary].reset_index(drop=True)
    b=de2[de2.signal_ts<boundary].reset_index(drop=True)
    assert len(a)>100 and len(a)==len(b),(len(a),len(b))
    for key in ('signal_ts','action','model_expected','model_lower','active_motifs'):
        assert a[key].equals(b[key]),('future-data leak',key)
    for tr in (tr1,tr2):
        if len(tr)>1:assert np.all(tr.entry_ts.iloc[1:].to_numpy()>=tr.exit_ts.iloc[:-1].to_numpy())
    print('PASS V6 future price perturbation cannot influence pre-maturity decisions or overlapping paper positions')

if __name__=='__main__':
    test_locked();test_maturity_and_resume();test_causal_future_and_paper();print('ALL V6 TESTS PASSED')
