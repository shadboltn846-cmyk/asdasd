"""Chronological development-only research. Does not use or read locked dates."""
from __future__ import annotations
import argparse, json, sys, time, hashlib
from pathlib import Path
import pandas as pd
from brain.core import PatternBrain,load_day,encode,run_day,LOCKED
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'/'5s_features'
OUT=ROOT/'results'

def run(args):
    OUT.mkdir(exist_ok=True)
    paths=sorted(DATA.glob('*_5s_features.csv'))
    if len(paths)!=20 or any(p.name[:10] in LOCKED for p in paths):
        raise RuntimeError(f'Development firewall mismatch: expected 20 nonlocked days; found {len(paths)}')
    requested=[] if not args.dates else args.dates.split(',')
    if any(x in LOCKED for x in requested):raise PermissionError('Locked dates never enter development replay.')
    paths=[p for p in paths if not requested or p.name[:10] in requested]
    if not paths:raise ValueError('No matching development days.')
    brain=None;summary=[];first=True
    for k,path in enumerate(paths):
        date,d=load_day(path)
        if brain is None:brain=PatternBrain(encode(d).shape[1])
        start=time.monotonic()
        outcome,trades,decisions=run_day(brain,d,date,cost=args.cost,
                     export_ghosts=(OUT/f'{date}_ALL_5S_GHOSTS.npz') if args.save_ghosts else None)
        outcome['runtime_sec']=round(time.monotonic()-start,2)
        outcome['cost_assumption']=args.cost
        summary.append(outcome)
        if not trades.empty:trades.to_csv(OUT/f'{date}_PAPER_TRADES.csv',index=False)
        decisions.to_csv(OUT/f'{date}_DECISIONS.csv',index=False)
        pd.DataFrame(summary).to_csv(OUT/'DAY_BY_DAY.csv',index=False)
        print(json.dumps(outcome),flush=True)
    df=pd.DataFrame(summary)
    assessment={'development_dates':len(df),'mean_net_per_date':float(df.net_points.mean()),
                'worst_day':float(df.net_points.min()),'negative_days':int((df.net_points<0).sum()),
                'sum_net':float(df.net_points.sum()),'total_paper_trades':int(df.trade_count.sum()),
                'meets_300_0':bool(df.net_points.mean()>=300 and (df.net_points>=0).all()),
                'statement':'RESEARCH ONLY. Previously examined dev days. No live claims; fill costs hypothetical.',
                'cost_points':args.cost,'reserved_dates_never_loaded':sorted(LOCKED)}
    (OUT/'SCORECARD.json').write_text(json.dumps(assessment,indent=2),encoding='utf-8')
    print('SCORECARD',json.dumps(assessment),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--dates',default='',help='Comma-separated development dates, or all 20 by default')
    p.add_argument('--cost',type=float,default=3.)
    p.add_argument('--save-ghosts',action='store_true',help='Save complete 5-second two-sided outcome surfaces as NPZ')
    args=p.parse_args();run(args)
