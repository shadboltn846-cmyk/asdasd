from __future__ import annotations

"""
GOLD AUCTION RESPONSE V4 — HOT250 + COLD RECOVERY
=================================================

Research/replay implementation of the current Gold system.

Layers
------
1) Auction Response entries (same V1 entry construction)
2) V2 post-entry trade management
3) Loss-cluster governor: 3 completed trades with pnl < -20 -> pause 60 min
4) Cold-start governor:
   - FAST: after first 5 trades, if cumulative <= -50, all 5 INVALID,
     and none reached +35 MFE -> normal mode is declared cold
   - SLOW: if first 15 trades never put cumulative pnl above 0, all 15 are
     INVALID, and none reached +35 MFE, allow trade 16 as one final probe.
     If trade 16 also has MFE < +35 -> normal mode is declared cold.
5) Cold recovery:
   - normal strategy is disabled once cold is confirmed
   - subsequent Auction Response candidates are traded in the OPPOSITE direction
   - TP up to +40, SL -30, max hold 45 min, 10 min cooldown
   - the last TP shrinks to exactly the points required to return the day to 0
   - once the day reaches 0, stop for the day
6) HOT250 checkpoint:
   - after a completed normal trade first takes realized daily pnl >= +250,
     evaluate the market state using only data known at that moment
   - HOT if either:
       30-min directional efficiency >= 0.17
       OR 60-min 90th-percentile volume strength >= 6.25x baseline
   - not HOT -> stop for the day and bank the crossing trade's full result
   - HOT -> keep the normal strategy running
   - after a completed trade takes realized pnl >= +600, stop for the day
     (the crossing trade is not clipped, so final pnl may be > +600)

Execution boundary
------------------
This module does NOT call MetaTrader5.order_send or any broker API.  It is the
full strategy/replay state logic.  Connect its entry/exit decisions to a
separate execution adapter only after validation.

Point convention: 10 strategy points = $1.00 XAUUSD price move.
"""

from dataclasses import dataclass, asdict
from typing import Optional
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

# =============================================================================
# POINT / BAR CONVENTION
# =============================================================================
BAR_SECONDS = 5
POINTS_PER_DOLLAR = 10.0

# =============================================================================
# AUCTION RESPONSE ENTRY LOGIC — frozen V1 thresholds
# =============================================================================
DELTA_STRENGTH_MIN = 1.5
VOLUME_STRENGTH_MIN = 1.0
ACCEPT_RESPONSE_MIN = 0.30
ACCEPT_BOOK_VACUUM_MIN = 0.0
REJECT_RESPONSE_MAX = 0.0
REJECT_WEAKEN_RATIO = 0.75
BASELINE_SECONDS = 600
BASELINE_MIN_SECONDS = 120
BRANCH_DEDUP_SECONDS = 120

BRANCH_REJECT = 1
BRANCH_ACCEPT = 2
BRANCH_NAMES = {BRANCH_REJECT: "REJECT", BRANCH_ACCEPT: "ACCEPT"}

# =============================================================================
# V2 TRADE MANAGER
# =============================================================================
HARD_SL_POINTS = 100.0
TARGET_POINTS = 280.0
MAX_HOLD_SECONDS = 5400  # 90 min
PROTECTION_LADDER = (
    (40.0, -20.0),
    (75.0, 0.0),
    (120.0, 30.0),
    (180.0, 80.0),
    (230.0, 140.0),
)

# =============================================================================
# LOSS-CLUSTER GOVERNOR
# =============================================================================
LOSS_CLUSTER_STREAK = 3
LOSS_CLUSTER_TRADE_PNL_LT = -20.0  # strictly less than -20
LOSS_CLUSTER_PAUSE_SECONDS = 3600

# =============================================================================
# HOT250 CHECKPOINT
# =============================================================================
HOT_CHECKPOINT_POINTS = 250.0
HOT_EFFICIENCY_LOOKBACK_SECONDS = 30 * 60
HOT_EFFICIENCY_MIN = 0.17
HOT_VOLUME_LOOKBACK_SECONDS = 60 * 60
HOT_VOLUME_P90_MIN = 6.25
HOT_FINAL_STOP_POINTS = 600.0

# =============================================================================
# COLD-START GOVERNOR
# =============================================================================
COLD_PROOF_MFE_POINTS = 35.0
COLD_FAST_N = 5
COLD_FAST_CUM_PNL_MAX = -50.0
COLD_SLOW_N = 15
COLD_PROBE_TRADE_NUMBER = 16

# =============================================================================
# COLD RECOVERY
# =============================================================================
RECOVERY_TP_MAX_POINTS = 40.0
RECOVERY_SL_POINTS = 30.0
RECOVERY_MAX_HOLD_SECONDS = 45 * 60
RECOVERY_COOLDOWN_SECONDS = 10 * 60
RECOVERY_DONE_PNL = 0.0


@dataclass(frozen=True)
class V4Spec:
    name: str = "GOLD AUCTION RESPONSE V4 — HOT250 + COLD RECOVERY"
    point_convention: str = "10 points = $1.00 XAUUSD move"
    bar_seconds: int = BAR_SECONDS
    hard_sl_points: float = HARD_SL_POINTS
    target_points: float = TARGET_POINTS
    max_hold_seconds: int = MAX_HOLD_SECONDS
    loss_cluster_streak: int = LOSS_CLUSTER_STREAK
    loss_cluster_trade_pnl_lt: float = LOSS_CLUSTER_TRADE_PNL_LT
    loss_cluster_pause_seconds: int = LOSS_CLUSTER_PAUSE_SECONDS
    hot_checkpoint_points: float = HOT_CHECKPOINT_POINTS
    hot_efficiency_lookback_seconds: int = HOT_EFFICIENCY_LOOKBACK_SECONDS
    hot_efficiency_min: float = HOT_EFFICIENCY_MIN
    hot_volume_lookback_seconds: int = HOT_VOLUME_LOOKBACK_SECONDS
    hot_volume_p90_min: float = HOT_VOLUME_P90_MIN
    hot_final_stop_points: float = HOT_FINAL_STOP_POINTS
    cold_proof_mfe_points: float = COLD_PROOF_MFE_POINTS
    cold_fast_n: int = COLD_FAST_N
    cold_fast_cum_pnl_max: float = COLD_FAST_CUM_PNL_MAX
    cold_slow_n: int = COLD_SLOW_N
    recovery_tp_max_points: float = RECOVERY_TP_MAX_POINTS
    recovery_sl_points: float = RECOVERY_SL_POINTS
    recovery_max_hold_seconds: int = RECOVERY_MAX_HOLD_SECONDS
    recovery_cooldown_seconds: int = RECOVERY_COOLDOWN_SECONDS
    broker_order_authority_in_this_module: bool = False


def spec_dict() -> dict:
    return asdict(V4Spec())


# =============================================================================
# TIME HELPERS
# =============================================================================
def eastern_score_bounds(date_str: str, start_hour: int = 0, end_hour: int = 15) -> tuple[int, int]:
    """Return UTC epoch bounds for an America/New_York trading-day window.

    Handles EST/EDT automatically.  The research window has been 00:00-15:00 ET.
    """
    tz = ZoneInfo("America/New_York")
    day = pd.Timestamp(date_str).date()
    start_local = pd.Timestamp(day).replace(hour=start_hour, tzinfo=tz)
    end_local = pd.Timestamp(day).replace(hour=end_hour, tzinfo=tz)
    return int(start_local.timestamp()), int(end_local.timestamp())


# =============================================================================
# V1 FEATURE + CANDIDATE CONSTRUCTION
# =============================================================================
def compute_features(df5: pd.DataFrame) -> pd.DataFrame:
    """Compute causal Auction Response features from merged 5-second bars.

    Required columns
    ----------------
    ts, x_open, x_high, x_low, x_close,
    buy_vol, sell_vol, add_bid, add_ask, cancel_bid, cancel_ask

    `ts` is UTC epoch seconds at the 5-second bar start.
    """
    d = df5.copy().reset_index(drop=True)
    required = [
        "ts", "x_open", "x_high", "x_low", "x_close",
        "buy_vol", "sell_vol", "add_bid", "add_ask", "cancel_bid", "cancel_ask",
    ]
    missing = [c for c in required if c not in d.columns]
    if missing:
        raise ValueError(f"Missing required 5s columns: {missing}")

    d["delta"] = d["buy_vol"].astype(float) - d["sell_vol"].astype(float)
    d["vol"] = d["buy_vol"].astype(float) + d["sell_vol"].astype(float)
    d["xret"] = (d["x_close"].astype(float) - d["x_open"].astype(float)) * POINTS_PER_DOLLAR
    d["range"] = (d["x_high"].astype(float) - d["x_low"].astype(float)) * POINTS_PER_DOLLAR

    lb = max(8, BASELINE_SECONDS // BAR_SECONDS)
    mp = max(4, BASELINE_MIN_SECONDS // BAR_SECONDS)

    def medpast(s: pd.Series) -> pd.Series:
        return s.shift(1).rolling(lb, min_periods=mp).median()

    d["absdelta_base"] = medpast(d["delta"].abs()).replace(0, np.nan)
    d["vol_base"] = medpast(d["vol"]).replace(0, np.nan)
    d["range_base"] = medpast(d["range"]).replace(0, np.nan)

    d["delta_str"] = d["delta"].abs() / (d["absdelta_base"] + 1e-9)
    d["vol_str"] = d["vol"] / (d["vol_base"] + 1e-9)
    d["price_signed"] = np.sign(d["delta"]) * d["xret"]
    d["response"] = d["price_signed"] / (d["range_base"] + 1e-9)

    pos = d["delta"] > 0
    d["ahead_cancel"] = np.where(pos, d["cancel_ask"], d["cancel_bid"])
    d["ahead_add"] = np.where(pos, d["add_ask"], d["add_bid"])
    d["book_vacuum"] = (
        (d["ahead_cancel"] - d["ahead_add"])
        / (d["ahead_cancel"] + d["ahead_add"] + 1.0)
    )
    return d


def generate_candidates(features: pd.DataFrame) -> pd.DataFrame:
    """Generate deduplicated Auction Response candidates.

    REJECT gets precedence if a completed 5-second bar qualifies for both.
    Entry is always the NEXT 5-second bar open.
    """
    d = features
    strong = (
        (d["delta_str"] >= DELTA_STRENGTH_MIN)
        & (d["vol_str"] >= VOLUME_STRENGTH_MIN)
    )
    side = np.sign(d["delta"]).fillna(0).astype(int)

    acc = (
        strong
        & (d["response"] >= ACCEPT_RESPONSE_MIN)
        & (d["book_vacuum"] >= ACCEPT_BOOK_VACUUM_MIN)
    )

    prev_rej = (strong & (d["response"] <= REJECT_RESPONSE_MAX)).shift(1).fillna(False)
    prev_side = np.sign(d["delta"].shift(1)).fillna(0).astype(int)
    breakaway = pd.Series(
        np.where(
            prev_side > 0,
            d["x_close"] < d["x_low"].shift(1),
            d["x_close"] > d["x_high"].shift(1),
        ),
        index=d.index,
        dtype=bool,
    )
    fade = -prev_side
    weak = (
        (np.sign(d["delta"]) == fade)
        | (d["delta"].abs() <= d["delta"].abs().shift(1) * REJECT_WEAKEN_RATIO)
    )
    rej = prev_rej & breakaway & weak

    direction = np.where(rej, fade, np.where(acc, side, 0)).astype(np.int8)
    branch = np.where(rej, BRANCH_REJECT, np.where(acc, BRANCH_ACCEPT, 0)).astype(np.int8)

    idx = np.where((branch > 0) & (direction != 0))[0]
    cool_bars = BRANCH_DEDUP_SECONDS // BAR_SECONDS
    last = {BRANCH_REJECT: -10**12, BRANCH_ACCEPT: -10**12}
    keep: list[int] = []
    for i in idx:
        b = int(branch[i])
        if int(i) - last[b] >= cool_bars:
            keep.append(int(i))
            last[b] = int(i)

    rows: list[dict] = []
    for i in keep:
        rows.append({
            "signal_i": i,
            "signal_ts": int(d.at[i, "ts"]),
            "direction": int(direction[i]),
            "branch": int(branch[i]),
            "branch_name": BRANCH_NAMES[int(branch[i])],
            "delta": float(d.at[i, "delta"]),
            "delta_str": float(d.at[i, "delta_str"]),
            "vol_str": float(d.at[i, "vol_str"]),
            "response": float(d.at[i, "response"]),
            "book_vacuum": float(d.at[i, "book_vacuum"]),
        })
    return pd.DataFrame(rows)


# =============================================================================
# ONE NORMAL V2 TRADE
# =============================================================================
def _simulate_normal_trade(d: pd.DataFrame, c, entry_i: int) -> dict:
    ts = d["ts"].to_numpy(np.int64)
    op = d["x_open"].to_numpy(float)
    hi = d["x_high"].to_numpy(float)
    lo = d["x_low"].to_numpy(float)
    cl = d["x_close"].to_numpy(float)
    delta = d["delta"].to_numpy(float)

    i = int(c.signal_i)
    direction = int(c.direction)
    branch = int(c.branch)
    entry = float(op[entry_i])
    hold_bars = max(1, MAX_HOLD_SECONDS // BAR_SECONDS)
    end_i = min(len(d) - 1, i + hold_bars)

    local_delta = delta[entry_i:end_i + 1] * direction
    prefix = np.r_[0.0, np.cumsum(local_delta)]

    mfe = 0.0
    mae = 0.0
    floor = -HARD_SL_POINTS
    reason = "TIME"
    exit_i = end_i
    exit_price = float(cl[end_i])
    pnl = (exit_price - entry) * POINTS_PER_DOLLAR * direction

    for j in range(entry_i, end_i + 1):
        if direction > 0:
            fav = (float(hi[j]) - entry) * POINTS_PER_DOLLAR
            adv = (float(lo[j]) - entry) * POINTS_PER_DOLLAR
        else:
            fav = (entry - float(lo[j])) * POINTS_PER_DOLLAR
            adv = (entry - float(hi[j])) * POINTS_PER_DOLLAR

        mfe = max(mfe, fav)
        mae = min(mae, adv)

        for trigger, new_floor in PROTECTION_LADDER:
            if mfe >= trigger:
                floor = max(floor, new_floor)

        # Conservative same-bar rule: stop/protection before target.
        if adv <= floor:
            pnl = float(floor)
            reason = "PROTECT" if floor > -HARD_SL_POINTS else "SL"
            exit_i = j
            exit_price = entry + (pnl / POINTS_PER_DOLLAR) * direction
            break

        if fav >= TARGET_POINTS:
            pnl = float(TARGET_POINTS)
            reason = "TP"
            exit_i = j
            exit_price = entry + (TARGET_POINTS / POINTS_PER_DOLLAR) * direction
            break

        k = j - entry_i + 1
        age_seconds = k * BAR_SECONDS
        current_pnl = (float(cl[j]) - entry) * POINTS_PER_DOLLAR * direction

        def aligned_delta_sum(window_seconds: int) -> float:
            n = min(k, window_seconds // BAR_SECONDS)
            return float(prefix[k] - prefix[k - n])

        invalid = False
        if branch == BRANCH_ACCEPT:
            if age_seconds >= 180 and current_pnl <= 0 and aligned_delta_sum(60) <= 0:
                invalid = True
        elif branch == BRANCH_REJECT:
            if age_seconds >= 120 and current_pnl <= 0 and aligned_delta_sum(60) <= 0:
                invalid = True

        if (
            not invalid
            and age_seconds >= 300
            and current_pnl <= 0
            and aligned_delta_sum(120) <= 0
        ):
            invalid = True

        if invalid:
            pnl = float(current_pnl)
            reason = "INVALID"
            exit_i = j
            exit_price = float(cl[j])
            break

    return {
        "signal_i": i,
        "signal_ts": int(c.signal_ts),
        "entry_i": int(entry_i),
        "entry_ts": int(ts[entry_i]),
        "exit_i": int(exit_i),
        "exit_ts": int(ts[exit_i]),
        "direction": direction,
        "branch": branch,
        "branch_name": str(c.branch_name),
        "entry": entry,
        "exit": float(exit_price),
        "pnl_points": float(pnl),
        "mfe_points": float(mfe),
        "mae_points": float(mae),
        "reason": reason,
        "mode": "NORMAL",
    }


# =============================================================================
# HOT250 MARKET-STATE CHECK
# =============================================================================
def hot250_metrics(features: pd.DataFrame, checkpoint_exit_ts: int) -> dict:
    """Calculate the exact two causal features used at the +250 checkpoint."""
    d = features

    w30 = d[
        (d["ts"] >= int(checkpoint_exit_ts) - HOT_EFFICIENCY_LOOKBACK_SECONDS)
        & (d["ts"] <= int(checkpoint_exit_ts))
    ]
    if len(w30) < 2:
        efficiency30 = 0.0
        net30 = 0.0
        path30 = 0.0
    else:
        net30 = abs(
            (float(w30["x_close"].iloc[-1]) - float(w30["x_close"].iloc[0]))
            * POINTS_PER_DOLLAR
        )
        path30 = float(w30["xret"].abs().sum())
        efficiency30 = float(net30 / (path30 + 1e-9))

    w60 = d[
        (d["ts"] >= int(checkpoint_exit_ts) - HOT_VOLUME_LOOKBACK_SECONDS)
        & (d["ts"] <= int(checkpoint_exit_ts))
    ]
    vals = w60["vol_str"].to_numpy(float) if len(w60) else np.array([], dtype=float)
    vals = vals[np.isfinite(vals)]
    volume_p90_60 = float(np.percentile(vals, 90)) if len(vals) else 0.0

    hot = bool(
        efficiency30 >= HOT_EFFICIENCY_MIN
        or volume_p90_60 >= HOT_VOLUME_P90_MIN
    )
    return {
        "hot": hot,
        "efficiency30": efficiency30,
        "net30_points": net30,
        "path30_points": path30,
        "volume_strength_p90_60": volume_p90_60,
        "efficiency_threshold": HOT_EFFICIENCY_MIN,
        "volume_p90_threshold": HOT_VOLUME_P90_MIN,
    }


# =============================================================================
# ONE COLD-RECOVERY TRADE
# =============================================================================
def _simulate_recovery_trade(
    d: pd.DataFrame,
    c,
    entry_i: int,
    realized_before: float,
) -> dict:
    """Trade the next Auction Response candidate in the OPPOSITE direction.

    The TP is min(+40, points needed to return daily realized pnl to exactly 0).
    There is no V2 invalidation or protection ladder in recovery mode.
    """
    ts = d["ts"].to_numpy(np.int64)
    op = d["x_open"].to_numpy(float)
    hi = d["x_high"].to_numpy(float)
    lo = d["x_low"].to_numpy(float)
    cl = d["x_close"].to_numpy(float)

    original_direction = int(c.direction)
    direction = -original_direction
    entry = float(op[entry_i])
    need_to_flat = max(0.0, -float(realized_before))
    target = min(RECOVERY_TP_MAX_POINTS, need_to_flat)

    hold_bars = max(1, RECOVERY_MAX_HOLD_SECONDS // BAR_SECONDS)
    end_i = min(len(d) - 1, entry_i + hold_bars - 1)

    reason = "TIME"
    exit_i = end_i
    exit_price = float(cl[end_i])
    pnl = (exit_price - entry) * POINTS_PER_DOLLAR * direction
    mfe = 0.0
    mae = 0.0

    if target <= 1e-12:
        return {
            "signal_i": int(c.signal_i),
            "signal_ts": int(c.signal_ts),
            "entry_i": int(entry_i),
            "entry_ts": int(ts[entry_i]),
            "exit_i": int(entry_i),
            "exit_ts": int(ts[entry_i]),
            "direction": direction,
            "original_direction": original_direction,
            "branch": int(c.branch),
            "branch_name": str(c.branch_name),
            "entry": entry,
            "exit": entry,
            "pnl_points": 0.0,
            "mfe_points": 0.0,
            "mae_points": 0.0,
            "target_points": 0.0,
            "reason": "ALREADY_FLAT",
            "mode": "COLD_RECOVERY",
        }

    for j in range(entry_i, end_i + 1):
        if direction > 0:
            fav = (float(hi[j]) - entry) * POINTS_PER_DOLLAR
            adv = (float(lo[j]) - entry) * POINTS_PER_DOLLAR
        else:
            fav = (entry - float(lo[j])) * POINTS_PER_DOLLAR
            adv = (entry - float(hi[j])) * POINTS_PER_DOLLAR

        mfe = max(mfe, fav)
        mae = min(mae, adv)

        # Conservative same-bar precedence: recovery SL before TP.
        if adv <= -RECOVERY_SL_POINTS:
            pnl = -RECOVERY_SL_POINTS
            reason = "RECOVERY_SL"
            exit_i = j
            exit_price = entry + (pnl / POINTS_PER_DOLLAR) * direction
            break

        if fav >= target:
            pnl = float(target)
            reason = "RECOVERY_TP"
            exit_i = j
            exit_price = entry + (pnl / POINTS_PER_DOLLAR) * direction
            break

    return {
        "signal_i": int(c.signal_i),
        "signal_ts": int(c.signal_ts),
        "entry_i": int(entry_i),
        "entry_ts": int(ts[entry_i]),
        "exit_i": int(exit_i),
        "exit_ts": int(ts[exit_i]),
        "direction": direction,
        "original_direction": original_direction,
        "branch": int(c.branch),
        "branch_name": str(c.branch_name),
        "entry": entry,
        "exit": float(exit_price),
        "pnl_points": float(pnl),
        "mfe_points": float(mfe),
        "mae_points": float(mae),
        "target_points": float(target),
        "reason": reason,
        "mode": "COLD_RECOVERY",
    }


# =============================================================================
# FULL DAY SIMULATOR
# =============================================================================
def simulate_v4_day(
    features: pd.DataFrame,
    candidates: pd.DataFrame,
    score_start_utc: int,
    score_end_utc: int,
) -> tuple[pd.DataFrame, dict]:
    """Run one trading day through the complete V4 state machine.

    Returns
    -------
    trades : DataFrame
        Normal + recovery trades in chronological order.
    summary : dict
        Final PnL and state diagnostics.
    """
    d = features.copy().reset_index(drop=True)
    if "delta" not in d.columns:
        d["delta"] = d["buy_vol"].astype(float) - d["sell_vol"].astype(float)
    if "xret" not in d.columns:
        d["xret"] = (d["x_close"].astype(float) - d["x_open"].astype(float)) * POINTS_PER_DOLLAR
    if "vol_str" not in d.columns:
        raise ValueError("features must contain vol_str; use compute_features(raw_5s) first")

    if candidates is None or len(candidates) == 0:
        return pd.DataFrame(), {
            "final_pnl_points": 0.0,
            "mode_end": "NO_TRADES",
            "hot250_reached": False,
            "hot250_hot": False,
            "cold_triggered": False,
            "recovered_to_zero": False,
            "trades": 0,
        }

    ts = d["ts"].to_numpy(np.int64)

    # Generic state
    realized = 0.0
    normal_free_i = -1
    pause_until_ts = -1
    consecutive_meaningful_losses = 0
    rows: list[dict] = []
    done = False

    # HOT250 state
    hot250_reached = False
    hot250_hot = False
    hot250_info: Optional[dict] = None

    # Cold state
    cold_triggered = False
    cold_trigger_kind: Optional[str] = None
    cold_trigger_trade_number: Optional[int] = None
    slow_probe_pending = False
    slow_probe_passed = False

    # Recovery state
    recovery_mode = False
    recovery_free_i = -1
    recovery_cooldown_until_ts = -1
    recovery_trade_count = 0
    recovered_to_zero = False

    normal_trades: list[dict] = []

    for c in candidates.itertuples(index=False):
        if done:
            break

        i = int(c.signal_i)
        entry_i = i + 1
        if entry_i >= len(d):
            continue
        entry_ts = int(ts[entry_i])
        if entry_ts < int(score_start_utc) or entry_ts >= int(score_end_utc):
            continue

        # ------------------------------------------------------------------
        # COLD RECOVERY MODE
        # ------------------------------------------------------------------
        if recovery_mode:
            if i < recovery_free_i:
                continue
            if entry_ts < recovery_cooldown_until_ts:
                continue

            tr = _simulate_recovery_trade(d, c, entry_i, realized)
            realized += float(tr["pnl_points"])
            # TP is dynamically sized, so numerical overshoot should not occur.
            if realized > 0 and realized < 1e-7:
                realized = 0.0
            tr["realized_after"] = float(realized)
            rows.append(tr)
            recovery_trade_count += 1
            recovery_free_i = int(tr["exit_i"]) + 1
            recovery_cooldown_until_ts = int(tr["exit_ts"]) + RECOVERY_COOLDOWN_SECONDS

            if realized >= RECOVERY_DONE_PNL - 1e-9:
                realized = 0.0
                rows[-1]["realized_after"] = 0.0
                recovered_to_zero = True
                done = True
            continue

        # ------------------------------------------------------------------
        # NORMAL MODE
        # ------------------------------------------------------------------
        if i < normal_free_i:
            continue
        if entry_ts < pause_until_ts:
            continue

        tr = _simulate_normal_trade(d, c, entry_i)
        realized += float(tr["pnl_points"])
        tr["realized_after"] = float(realized)
        rows.append(tr)
        normal_trades.append(tr)
        normal_free_i = int(tr["exit_i"]) + 1
        n = len(normal_trades)

        # Loss-cluster pause is causal and based on completed normal trades.
        if float(tr["pnl_points"]) < LOSS_CLUSTER_TRADE_PNL_LT:
            consecutive_meaningful_losses += 1
        else:
            consecutive_meaningful_losses = 0
        if consecutive_meaningful_losses >= LOSS_CLUSTER_STREAK:
            pause_until_ts = int(tr["exit_ts"]) + LOSS_CLUSTER_PAUSE_SECONDS
            consecutive_meaningful_losses = 0

        # --------------------------------------------------------------
        # COLD-START CHECKS
        # --------------------------------------------------------------
        if not hot250_reached and not cold_triggered:
            # Fast cold failure after exactly the first 5 completed trades.
            if n == COLD_FAST_N:
                p = normal_trades[:COLD_FAST_N]
                if (
                    sum(float(x["pnl_points"]) for x in p) <= COLD_FAST_CUM_PNL_MAX
                    and all(str(x["reason"]) == "INVALID" for x in p)
                    and all(float(x["mfe_points"]) < COLD_PROOF_MFE_POINTS for x in p)
                ):
                    cold_triggered = True
                    cold_trigger_kind = "FAST_COLD"
                    cold_trigger_trade_number = COLD_FAST_N
                    recovery_mode = True
                    recovery_free_i = int(tr["exit_i"]) + 1
                    recovery_cooldown_until_ts = int(tr["exit_ts"])
                    # Once cold is confirmed, normal pause state no longer matters.
                    continue

            # At trade 15, decide whether trade 16 must act as the final probe.
            if n == COLD_SLOW_N and not slow_probe_passed:
                p = normal_trades[:COLD_SLOW_N]
                cum = np.cumsum([float(x["pnl_points"]) for x in p])
                if (
                    float(np.max(cum)) <= 0.0
                    and all(str(x["reason"]) == "INVALID" for x in p)
                    and all(float(x["mfe_points"]) < COLD_PROOF_MFE_POINTS for x in p)
                ):
                    slow_probe_pending = True

            # Trade 16 is the one final proof probe if trade 15 armed it.
            elif n == COLD_PROBE_TRADE_NUMBER and slow_probe_pending:
                if float(tr["mfe_points"]) < COLD_PROOF_MFE_POINTS:
                    cold_triggered = True
                    cold_trigger_kind = "SLOW_PROBE_FAIL"
                    cold_trigger_trade_number = COLD_PROBE_TRADE_NUMBER
                    recovery_mode = True
                    recovery_free_i = int(tr["exit_i"]) + 1
                    recovery_cooldown_until_ts = int(tr["exit_ts"])
                    continue
                else:
                    slow_probe_pending = False
                    slow_probe_passed = True

        # --------------------------------------------------------------
        # HOT250 CHECKPOINT / FINAL HOT-DAY STOP
        # --------------------------------------------------------------
        if not hot250_reached and realized >= HOT_CHECKPOINT_POINTS:
            hot250_reached = True
            hot250_info = hot250_metrics(d, int(tr["exit_ts"]))
            hot250_hot = bool(hot250_info["hot"])
            if not hot250_hot:
                done = True
                continue

        if hot250_reached and hot250_hot and realized >= HOT_FINAL_STOP_POINTS:
            # Do not clip the trade that crosses +600; bank the full closed trade.
            done = True
            continue

    trades = pd.DataFrame(rows)
    if not trades.empty:
        trades = trades.copy()
        # Preserve useful internal indices for regression/debugging, but put readable
        # columns first.
        first = [
            "mode", "entry_ts", "exit_ts", "direction", "branch_name",
            "pnl_points", "realized_after", "mfe_points", "mae_points", "reason",
        ]
        cols = [c for c in first if c in trades.columns] + [c for c in trades.columns if c not in first]
        trades = trades[cols]

    if recovery_mode and not recovered_to_zero:
        mode_end = "COLD_RECOVERY_UNFINISHED"
    elif recovered_to_zero:
        mode_end = "COLD_RECOVERED_TO_ZERO"
    elif hot250_reached and hot250_hot and realized >= HOT_FINAL_STOP_POINTS:
        mode_end = "HOT_STOP600"
    elif hot250_reached and not hot250_hot:
        mode_end = "STOP250"
    elif hot250_reached and hot250_hot:
        mode_end = "HOT_CONTINUE_END"
    else:
        mode_end = "NEVER250"

    summary = {
        "final_pnl_points": float(realized),
        "mode_end": mode_end,
        "trades": int(len(trades)),
        "normal_trades": int(sum(1 for x in rows if x.get("mode") == "NORMAL")),
        "recovery_trades": int(sum(1 for x in rows if x.get("mode") == "COLD_RECOVERY")),
        "hot250_reached": bool(hot250_reached),
        "hot250_hot": bool(hot250_hot),
        "hot250_metrics": hot250_info,
        "cold_triggered": bool(cold_triggered),
        "cold_trigger_kind": cold_trigger_kind,
        "cold_trigger_trade_number": cold_trigger_trade_number,
        "recovered_to_zero": bool(recovered_to_zero),
        "broker_order_authority_in_this_module": False,
    }
    return trades, summary


# =============================================================================
# SIMPLE LIVE-STATE HELPERS
# =============================================================================
def cold_prefix_status(completed_normal_trades: pd.DataFrame) -> dict:
    """Inspect a live day's already-CLOSED normal trades for cold-start state.

    This helper does not place trades.  It is useful for wiring the same logic
    into a real-time controller.
    """
    if completed_normal_trades is None or len(completed_normal_trades) == 0:
        return {"cold": False, "slow_probe_pending": False, "reason": None}

    t = completed_normal_trades.reset_index(drop=True)
    n = len(t)

    if n >= COLD_FAST_N:
        p = t.iloc[:COLD_FAST_N]
        if (
            float(p["pnl_points"].sum()) <= COLD_FAST_CUM_PNL_MAX
            and (p["reason"] == "INVALID").all()
            and (p["mfe_points"] < COLD_PROOF_MFE_POINTS).all()
        ):
            return {"cold": True, "slow_probe_pending": False, "reason": "FAST_COLD"}

    if n >= COLD_SLOW_N:
        p = t.iloc[:COLD_SLOW_N]
        cum = p["pnl_points"].cumsum()
        armed = bool(
            float(cum.max()) <= 0.0
            and (p["reason"] == "INVALID").all()
            and (p["mfe_points"] < COLD_PROOF_MFE_POINTS).all()
        )
        if armed and n == COLD_SLOW_N:
            return {"cold": False, "slow_probe_pending": True, "reason": "WAIT_FOR_TRADE16_PROBE"}
        if armed and n >= COLD_PROBE_TRADE_NUMBER:
            probe = t.iloc[COLD_PROBE_TRADE_NUMBER - 1]
            if float(probe["mfe_points"]) < COLD_PROOF_MFE_POINTS:
                return {"cold": True, "slow_probe_pending": False, "reason": "SLOW_PROBE_FAIL"}
            return {"cold": False, "slow_probe_pending": False, "reason": "SLOW_PROBE_PASS"}

    return {"cold": False, "slow_probe_pending": False, "reason": None}


if __name__ == "__main__":
    print(V4Spec())
    print("This module contains strategy/replay logic only; no broker order_send is present.")
