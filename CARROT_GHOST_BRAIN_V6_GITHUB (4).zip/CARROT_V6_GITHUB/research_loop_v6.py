"""Autonomous bounded experimental motif search using 14 development dates for
hypothesis generation and next 6 for forward diagnostic checks. NOT blind testing.

Repeated experimentation on these same 20 development dates creates selection bias;
never promote a strategy from these runs to real trading. No broker authority.
"""
from pathlib import Path
import argparse, hashlib, json, time, math
import numpy as np
from brain.core import ACTIONS, LOCKED, encode, load_day
from brain.v6 import GhostResearchBrain, run_v6_day, action_label
from run_v6 import ROOT,atomic_json,sha

SPLIT=14
MAX_EXPERIMENTS=12

def run(state_dir,out,cost=3.):
    state_dir=Path(state_dir).resolve();state_dir.mkdir(parents=True,exist_ok=True)
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    journal_path=state_dir/'research_history.json'
    journal=json.loads(journal_path.read_text()) if journal_path.exists() else {'experiments':[],'schema':'motif-tournament-v1'}
    if journal.get('schema')!='motif-tournament-v1':raise ValueError('Research journal schema mismatch')
    idx=len(journal['experiments'])
    if idx>=MAX_EXPERIMENTS:
        print('RESEARCH BUDGET STOP: experiment limit reached. No further fitting on these known dates.',flush=True)
        atomic_json(out/'V6_RESEARCH_HISTORY.json',journal)
        return
    paths=sorted((ROOT/'data'/'5s_features').glob('*_5s_features.csv'))
    if len(paths)!=20 or any(p.name[:10] in LOCKED for p in paths):
        raise RuntimeError('Development-only isolation check failed')
    datahash=hashlib.sha256(''.join(sha(p) for p in paths).encode()).hexdigest()
    if journal.get('data_fingerprint') and journal['data_fingerprint']!=datahash:
        raise RuntimeError('Research data has changed, refusing to merge unrelated experiments.')
    journal['data_fingerprint']=datahash
    seed=297+31*idx
    brain=None;days=[];train_ideas=[];train_counts=None;train_total=None;train_squares=None
    for k,p in enumerate(paths):
        date,d=load_day(p)
        if brain is None:brain=GhostResearchBrain(encode(d).shape[1],seed=seed)
        if k==SPLIT:
            train_ideas=brain.ideas(minimum_effective=10)[:8]
            train_counts=brain.count.copy();train_total=brain.total.copy();train_squares=brain.squares.copy()
            print('FROZEN',len(train_ideas),'training-generated candidate motifs before internal forward period',flush=True)
        summary,_,_=run_v6_day(brain,d,date,k,cost=cost)
        days.append(summary)
        print('EXPERIMENT',idx+1,date,'net',summary['net_points'],flush=True)
    from math import sqrt
    validation=[]
    for idea in train_ideas:
        a=next(i for i in range(len(ACTIONS)) if action_label(i)==idea['action'])
        motif=idea['motif'];count=float(brain.count[motif,a]-train_counts[motif,a])
        total=float(brain.total[motif,a]-train_total[motif,a])
        squares=float(brain.squares[motif,a]-train_squares[motif,a])
        _,_,_,_,h,stride=ACTIONS[a]
        eff=count*min(1,stride/h)
        mu=total/count if count else 0.
        var=max(400.,squares/max(1,count)-mu**2)
        lower=mu-2.8*sqrt(var/max(1.,eff))
        validation.append({**idea,'validation_count':int(count),'validation_effective_count':round(eff,1),
            'validation_mean_ghost_net':round(mu,3),'validation_penalized_lower':round(lower,3),
            'passes_exploratory_ghost_check':bool(count>0 and eff>=15 and lower>0)})
    internal=days[SPLIT:]
    full_net=round(sum(x['net_points'] for x in days),2)
    experiment={
        'experiment_number':idx+1,'representation_seed':seed,'source_version':'carrot-v6-r1',
        'all_development_net':full_net,'all_development_mean':round(full_net/20,2),
        'internal_forward_dates':[d['date'] for d in internal],
        'internal_forward_total_net':round(sum(d['net_points'] for d in internal),2),
        'internal_forward_negative_days':sum(d['net_points']<0 for d in internal),
        'total_paper_trades':sum(d['trade_count'] for d in days),
        'training_motif_ideas':train_ideas,'later_date_motif_checks':validation,
        'promoted_to_live':False,'promoted_to_paper':False,
        'data_fingerprint':datahash,'note':'Internal forward development check only; same known dates reused across experiments. Never call this an untouched holdout.'}
    journal['experiments'].append(experiment)
    atomic_json(journal_path,journal)
    atomic_json(out/f'V6_EXPERIMENT_{idx+1:02d}.json',experiment)
    atomic_json(out/'V6_RESEARCH_HISTORY.json',journal)
    print('EXPERIMENT_SCORECARD',json.dumps({k:v for k,v in experiment.items() if k not in ('training_motif_ideas','later_date_motif_checks')}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--state-dir',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--cost',type=float,default=3.)
    a=p.parse_args();run(a.state_dir,a.output,a.cost)
