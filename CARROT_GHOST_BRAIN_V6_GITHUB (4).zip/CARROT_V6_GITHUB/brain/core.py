"""CARROT Ghost Brain V5: causal, research-only online pattern discovery.

Every completed 5s market bar launches BUY and SELL counterfactuals across four exit plans.
All future outcome matrices are RESEARCH TRUTH. A decision at time i can consume only
outcomes whose FULL maximum horizon matured by bar i. No live broker integration.
OHLC both-hit bars pessimistically pay STOP first. No realistic bid/ask tick fills.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from pathlib import Path
import json, math
import numpy as np
import pandas as pd

BAR=5
SCALE=10.0
LOCKED=frozenset(('2026-03-03','2026-03-06','2026-04-14','2026-04-17','2026-06-10','2026-06-16','2026-08-24'))
# Research action space: scalp to original-V4 sized payoff. No parameter tuning on holdout.
PLANS=(('SCALP_1M',40.,30.,12,12),('PUSH_5M',100.,60.,60,36),
       ('TREND_15M',160.,80.,180,60),('V4_SCALE_90M',280.,100.,1080,180))
ACTIONS=[(direction,name,tp,sl,h,stride) for name,tp,sl,h,stride in PLANS for direction in (1,-1)]
FEATURE_LABELS=(
    'r_5s','r_30s','r_1m','r_5m','r_15m','r_1h','r_2h','r_4h',
    'vol_1m','vol_5m','vol_15m','vol_1h',
    'eff_1m','eff_5m','eff_15m','eff_1h',
    'delta_now','delta_mean_1m','delta_mean_5m','delta_mean_1h',
    'aggression_1m','aggression_5m','absorption_5m','book_vacuum',
    'churn_5m','impact_5m','impact_15m','relative_position_5m','relative_position_15m',
    'sweep_upper','sweep_lower','time_sin','time_cos'
)

def valid_date(path):
    name=Path(path).name[:10]
    if name in LOCKED:
        raise PermissionError('LOCKED historical date must not be loaded by the learner: '+name)
    return name

def load_day(path):
    date=valid_date(path)
    d=pd.read_csv(path)
    needed=['ts','x_open','x_high','x_low','x_close','delta','buy_vol','sell_vol',
            'add_bid','add_ask','cancel_bid','cancel_ask','book_vacuum']
    if any(c not in d for c in needed): raise ValueError('Missing columns: '+str([c for c in needed if c not in d]))
    t=d.ts.to_numpy(np.int64)
    if len(t)<500 or (np.diff(t)!=5).any() or not np.isfinite(d[['x_open','x_high','x_low','x_close']]).all().all():
        raise ValueError('Inadequate or non-contiguous input bars')
    if ((d.x_low>d.x_high)|(d.x_open>d.x_high+1e-7)|(d.x_open<d.x_low-1e-7)).any():
        raise ValueError('Invalid OHLC')
    return date,d

def _norm(v):
    v=np.asarray(v,dtype=float)
    return np.nan_to_num(v,nan=0.,posinf=0.,neginf=0.)

def encode(d):
    """Multiple views of complete historical sequences, not one scalar indicator.
    Every feature at index i uses bars <=i. Bars in the future are never used.
    Features are dimensionless, clipped, with rolling locally adaptive normalization.
    """
    close=d.x_close.astype(float); high=d.x_high.astype(float);low=d.x_low.astype(float)
    ret=close.diff().fillna(0)*SCALE
    ab=ret.abs(); local=ab.shift(1).rolling(120,min_periods=24).mean().fillna(4.).clip(lower=1.)
    delta=d.delta.astype(float)
    dref=delta.abs().shift(1).rolling(120,min_periods=24).mean().fillna(1.).clip(lower=1.)
    roll=lambda s,n: s.rolling(n,min_periods=max(3,int(n*.2))).mean()
    rsum=lambda s,n: s.rolling(n,min_periods=max(3,int(n*.2))).sum()
    X=[]
    for n in (1,6,12,60,180,720,1440,2880):
        X.append((close-close.shift(n)).fillna(0)*SCALE/(local*np.sqrt(n)+1e-6))
    for n in (12,60,180,720):
        X.append(roll(ab,n).fillna(0)/local)
    for n in (12,60,180,720):
        X.append((close-close.shift(n)).abs().fillna(0)*SCALE/(rsum(ab,n).fillna(0)+1e-6))
    X.append(np.arcsinh(delta/dref))
    for n in (12,60,720): X.append(roll(delta/dref,n).fillna(0))
    signed=np.sign(delta)
    aligned=(d.x_close.astype(float)-d.x_open.astype(float))*SCALE*signed
    for n in (12,60): X.append(roll(aligned,n).fillna(0)/(roll(ab,n).fillna(0)+1))
    X.append(roll(((delta.abs()/dref)>1.5)&(aligned<0),60).fillna(0))
    X.append(d.book_vacuum.fillna(0))
    canc=(d.cancel_bid.astype(float)+d.cancel_ask.astype(float))
    adds=(d.add_bid.astype(float)+d.add_ask.astype(float))
    X.append(roll((canc-adds)/(canc+adds+1),60).fillna(0))
    for n in (60,180):X.append(roll(aligned,n).fillna(0)/(roll(ab,n).fillna(0)+1))
    for n in (60,180):
        h=high.rolling(n,min_periods=12).max();l=low.rolling(n,min_periods=12).min()
        X.append(((close-l)/(h-l+1e-8)*2-1).fillna(0))
    h=high.shift(1).rolling(60,min_periods=12).max();l=low.shift(1).rolling(60,min_periods=12).min()
    X.append(((high-h)*SCALE/local).clip(lower=0).fillna(0))
    X.append(((l-low)*SCALE/local).clip(lower=0).fillna(0))
    secs=pd.to_datetime(d.ts,unit='s',utc=True).dt.tz_convert('America/New_York')
    tod=(secs.dt.hour*3600+secs.dt.minute*60+secs.dt.second).to_numpy()/86400*2*np.pi
    X += [np.sin(tod),np.cos(tod)]
    # The raw recent sequence is represented as a multiresolution set of temporal patches.
    # The unsupervised prototypes learn interactions among all views.
    ar=(ret/local).clip(-6,6)
    df=(np.arcsinh(delta/dref)).clip(-6,6)
    for series in (ar,df):
        for period,patches in ((24,4),(120,5),(720,4)):
            width=period//patches
            for k in range(patches):
                a=series.shift(k*width)
                X.append(roll(a,width).fillna(0))
    return np.clip(np.nan_to_num(np.column_stack([_norm(y) for y in X]),nan=0.,posinf=0.,neginf=0.),-5,5).astype('float32')

@dataclass
class GhostTruth:
    reward: np.ndarray
    exit_i: np.ndarray
    mfe: np.ndarray
    mae: np.ndarray
    ambiguous: np.ndarray
    reason: np.ndarray


def ghost_surface(d,cost=3.):
    """Compute complete BUY+SELL outcome surface every five seconds.
    Truth is materialized OFFLINE; learner may access a reward only after full plan horizon.
    Entry at *next* bar open; bars 1..H inclusive. Stop-first if both hit same OHLC.
    """
    n=len(d);op=d.x_open.to_numpy(float);hi=d.x_high.to_numpy(float);lo=d.x_low.to_numpy(float);cl=d.x_close.to_numpy(float)
    out=[];idx=np.arange(n)
    for side,name,tp,sl,h,stride in ACTIONS:
        entry=np.roll(op,-1)
        complete=idx+h<n
        active=complete.copy();exit_i=np.full(n,-1,dtype=np.int32)
        reward=np.full(n,np.nan,dtype=np.float32)
        mfe=np.zeros(n,dtype=np.float32);mae=np.zeros(n,dtype=np.float32)
        amb=np.zeros(n,dtype=np.uint8);reason=np.full(n,0,dtype=np.int8)
        for step in range(1,h+1):
            ids=np.flatnonzero(active & (idx+step<n))
            if len(ids)==0:break
            jj=ids+step
            fav=(hi[jj]-entry[ids])*SCALE if side==1 else (entry[ids]-lo[jj])*SCALE
            adv=(lo[jj]-entry[ids])*SCALE if side==1 else (entry[ids]-hi[jj])*SCALE
            mfe[ids]=np.maximum(mfe[ids],fav)
            mae[ids]=np.minimum(mae[ids],adv)
            sl_hit=adv<=-sl;tp_hit=fav>=tp
            stop_ids=ids[sl_hit];target_ids=ids[~sl_hit&tp_hit]
            if len(stop_ids):
                reward[stop_ids]=-sl-cost;reason[stop_ids]=1;exit_i[stop_ids]=jj[sl_hit]
                amb[stop_ids]=(tp_hit[sl_hit]).astype('uint8');active[stop_ids]=False
            if len(target_ids):
                reward[target_ids]=tp-cost;reason[target_ids]=2;exit_i[target_ids]=jj[~sl_hit&tp_hit];active[target_ids]=False
        ids=np.flatnonzero(active & complete)
        if len(ids):
            k=ids+h;reward[ids]=(cl[k]-entry[ids])*side*SCALE-cost
            reason[ids]=3;exit_i[ids]=k
        out.append(GhostTruth(reward,exit_i,mfe,mae,amb,reason))
    return out

class PatternBrain:
    """Causal, incremental latent-regime + payoff learner with confidence abstention.
    Every row is processed in chronological order. Cluster prototypes are unsupervised.
    Linear reward heads learn different conditional patterns for each direction/plan;
    recent and cluster-specific payoff posteriors adapt when the market shifts.
    """
    def __init__(self,dim,n_clusters=12,seed=27):
        rng=np.random.default_rng(seed)
        self.K=n_clusters;self.dim=dim;self.centroids=None;self.cluster_counts=np.zeros(n_clusters)
        self.buffer=[];self.w=np.zeros((len(ACTIONS),dim),dtype='float64')
        self.global_n=np.zeros(len(ACTIONS));self.global_sum=np.zeros(len(ACTIONS));self.global_sq=np.zeros(len(ACTIONS))
        self.local_n=np.zeros((n_clusters,len(ACTIONS)));self.local_sum=np.zeros_like(self.local_n)
        self.local_sq=np.zeros_like(self.local_n)
        self.recent=[deque() for _ in ACTIONS];self.last_change_bar=0
        self.drift=0.;self.seen_labels=0;self.seed=seed
        self.err_ema=0.;self.last_update=-1
    def cluster(self,x,update=False):
        v=np.asarray(x,dtype=float)
        if self.centroids is None:
            self.buffer.append(v.copy())
            if len(self.buffer)<self.K:
                return -1,5.
            # Deterministic online farthest-first initialization: no future rows.
            c=[self.buffer[0]]
            for _ in range(self.K-1):
                arr=np.stack(self.buffer)
                dd=np.min(np.sum((arr[:,None,:]-np.stack(c)[None,:,:])**2,axis=2),axis=1)
                c.append(arr[int(dd.argmax())])
            self.centroids=np.stack(c).astype(float)
            self.buffer=[]
        dist=np.sum((self.centroids-v)**2,axis=1)
        ix=int(np.argmin(dist));nov=float(np.sqrt(max(0.,dist[ix])/self.dim))
        if update:
            self.cluster_counts[ix]+=1
            alpha=min(0.04,1/(self.cluster_counts[ix]+10))
            self.centroids[ix]+=(v-self.centroids[ix])*alpha
        return ix,nov
    def update(self,action,x,clust,y,timestamp):
        if not np.isfinite(y):return
        a=int(action);y=float(y);xx=x.astype(float)
        # Online nonlinear state matching via learned regime prototypes and linear heads.
        prior=float(np.dot(self.w[a],xx))
        self.w[a] *= 0.999995
        err=float(np.clip(y-prior,-220,220))
        self.w[a] += (0.00035*err/(1+float(np.dot(xx,xx))/self.dim))*xx
        self.w[a]=np.clip(self.w[a],-20,20)
        self.global_n[a]+=1;self.global_sum[a]+=y;self.global_sq[a]+=y*y
        if clust>=0:
            self.local_n[clust,a]+=1;self.local_sum[clust,a]+=y;self.local_sq[clust,a]+=y*y
        q=self.recent[a];q.append((timestamp,y))
        while q and q[0][0]<timestamp-4*3600:q.popleft()
        self.seen_labels+=1
        # Changes in model residual size raise uncertainty and force stronger proof.
        z=min(3.,abs(err)/80.)
        self.err_ema=.995*self.err_ema+.005*z
        self.drift=max(0.,0.993*self.drift+0.007*(z-1.15))
        self.last_update=timestamp
    def predict(self,x,clust,nov,timestamp):
        results=[]
        for a in range(len(ACTIONS)):
            n=self.global_n[a]
            if n<8 or clust<0:
                results.append(dict(action=a,expected=-3.,uncertainty=999.,score=-999.,n=int(n)));continue
            global_mean=self.global_sum[a]/n
            lc=self.local_n[clust,a];lm=self.local_sum[clust,a]/max(1.,lc)
            state_mean=(lc*lm+20*global_mean)/(lc+20)
            lin=float(np.dot(self.w[a],x))
            rec=[y for t,y in self.recent[a] if t>=timestamp-7200]
            fast=float(np.mean(rec)) if len(rec)>=6 else global_mean
            expected=0.43*state_mean+0.32*fast+0.25*lin
            var=max(16.,self.global_sq[a]/n-global_mean**2)
            neff=min(n/3.,(lc+20)/3., max(1.,len(rec)/2.))
            uncertainty=math.sqrt(var/(neff+1))*(1+nov*.40+self.drift)
            # Risk penalty and minimum edge margin both precommitted, not fit to dates.
            score=expected-0.45*uncertainty-3.*self.drift
            results.append(dict(action=a,expected=expected,uncertainty=uncertainty,score=score,n=int(n)))
        return results
    def describe(self,x,clust,nov):
        return dict(pattern_id=clust,novelty=round(nov,3),drift=round(self.drift,3),
                    recent_price_displacement=float(x[3]),volatility_relative=float(x[9]),
                    momentum_1h=float(x[5]),aggression_bias=float(x[17]),
                    absorption_relative=float(x[22]),book_vacuum=float(x[23]),
                    observed_patterns=int(np.count_nonzero(self.cluster_counts)))

def run_day(brain,d,date,cost=3.,max_decisions=None,export_ghosts=None):
    """Prequential replay; outcomes in memory are NOT shown to brain before maturation.
    One actual paper position at a time; every bar still launches every ghost action.
    """
    x=encode(d);truth=ghost_surface(d,cost=cost)
    ts=d.ts.to_numpy(np.int64);n=len(d)
    learn_queue=deque();actions_ledger=[];decisions=[];scores=[]
    # Every 5-sec ghost is generated; train an embargoed, regularly spaced subset.
    # We use full H maturity, even when TP/SL was reached earlier.
    next_free=0;accepted=0;trained=0;decision_idx=0
    for i in range(n):
        # All completed outcomes are released only when the full horizon has ended.
        while learn_queue and learn_queue[0][0]<=i:
            maturity,j,a,cluster_at_j=learn_queue.popleft()
            y=truth[a].reward[j]
            if np.isfinite(y):brain.update(a,x[j],cluster_at_j,y,int(ts[i]+BAR));trained+=1
        cluster,nov=brain.cluster(x[i],update=True)
        for a,(side,name,tp,sl,h,stride) in enumerate(ACTIONS):
            if i%stride==0 and i+h<n:
                # queue arrival order must be maturity-sorted, not insertion order.
                learn_queue.append((i+h,i,a,cluster))
        # Different horizons cause out-of-order events! Sort the tiny queue by maturity.
        if i%12==0 and learn_queue:
            learn_queue=deque(sorted(learn_queue,key=lambda z:z[0]))
        if i+1>=n:continue
        # Score 00:00-15:00 Eastern only; bars used for warmup outside score period.
        local=pd.Timestamp(int(ts[i+1]),unit='s',tz='UTC').tz_convert('America/New_York')
        if local.date().isoformat()!=date or not (0<=local.hour<15):continue
        # Only one filled paper trade concurrently. Still learn ghosts while busy.
        if i<next_free: continue
        preds=brain.predict(x[i],cluster,nov,int(ts[i]+BAR))
        best=max(preds,key=lambda z:z['score'])
        # Abstention is explicit. Profitable prediction alone insufficient.
        selected=(best['score']>5. and best['uncertainty']<90. and
                  best['n']>=12 and nov<3.0 and brain.drift<1.5)
        action=int(best['action']) if selected else -1
        info=brain.describe(x[i],cluster,nov)
        row=dict(date=date,signal_ts=int(ts[i]),decision_ts=int(ts[i]+5),
                 action=action,action_name=(ACTIONS[action][1]+'_'+('BUY' if ACTIONS[action][0]==1 else 'SELL')) if selected else 'NO_TRADE',
                 model_expected=round(best['expected'],3),model_uncertainty=round(best['uncertainty'],3),
                 model_score=round(best['score'],3),label_count=best['n'],
                 **info)
        # All predictions are surfaced for deep inspection, not only chosen trade.
        for p in preds:
            row['score_'+ACTIONS[p['action']][1]+'_'+('B' if ACTIONS[p['action']][0]==1 else 'S')]=round(p['score'],2)
        if i%12==0 or selected:decisions.append(row)
        if selected and np.isfinite(truth[action].reward[i]):
            tr=truth[action];e=int(tr.exit_i[i]);next_free=max(i+1,e+1)
            paper=dict(row,entry_ts=int(ts[i+1]),exit_ts=int(ts[e]+5),exit_index=e,
                       entry_price=float(d.x_open.iat[i+1]),gross_points=float(tr.reward[i]+cost),
                       net_points=float(tr.reward[i]),mfe_points=float(tr.mfe[i]),
                       mae_points=float(tr.mae[i]),exit_reason=('NONE','SL','TP','TIME')[int(tr.reason[i])],
                       ambiguous_same_bar=bool(tr.ambiguous[i]))
            actions_ledger.append(paper);accepted+=1
        decision_idx+=1
        if max_decisions and decision_idx>=max_decisions:break
    daily_net=float(sum(q['net_points'] for q in actions_ledger))
    result=dict(date=date,net_points=daily_net,trade_count=accepted,
                positive_trades=sum(v['net_points']>0 for v in actions_ledger),
                labeled_ghosts=trained,brain_updates_total=brain.seen_labels,
                abstain_count=decision_idx-accepted)
    if export_ghosts is not None:
        np.savez_compressed(export_ghosts,ts=ts,features=x,action_names=np.array([p[1]+('_BUY' if p[0]==1 else '_SELL') for p in ACTIONS]),
            rewards=np.stack([t.reward for t in truth]),exit_indices=np.stack([t.exit_i for t in truth]),
            mfe=np.stack([t.mfe for t in truth]),mae=np.stack([t.mae for t in truth]),
            reasons=np.stack([t.reason for t in truth]),ambiguous=np.stack([t.ambiguous for t in truth]))
    return result,pd.DataFrame(actions_ledger),pd.DataFrame(decisions)
