"""V6 causal latent-motif ghost researcher. Offline/paper ONLY.

Patterns are random nonlinear projections of multiscale market sequences, not a fixed
human-selected taxonomy. Matured counterfactuals update a shrinkage estimator and
prequential forecast-error monitor. This does not constitute generative reasoning,
validated alpha, exchange-quality fills, or an executable trading system.
"""
from __future__ import annotations
from collections import deque
from pathlib import Path
import json, hashlib, math
import numpy as np
import pandas as pd
from .core import ACTIONS, BAR, LOCKED, encode, ghost_surface, valid_date

MOTIFS=24
SCHEMA='carrot-v6-r1'

def action_label(a):
    side,name,*_=ACTIONS[a]
    return name+('_BUY' if side==1 else '_SELL')

class GhostResearchBrain:
    def __init__(self, dim, seed=212):
        self.dim=dim
        r=np.random.default_rng(seed)
        # Sparse random projections create novel *joint* market-sequence patterns.
        W=np.zeros((dim,MOTIFS), dtype=float)
        for k in range(MOTIFS):
            indices=r.choice(dim, size=min(5,dim), replace=False)
            W[indices,k]=r.choice([-1,1],size=len(indices))/np.sqrt(len(indices))
        self.W=W
        self.count=np.zeros((MOTIFS*2,len(ACTIONS)))
        self.total=np.zeros_like(self.count)
        self.squares=np.zeros_like(self.count)
        self.daymask=np.zeros_like(self.count,dtype=np.uint32)
        self.global_n=np.zeros(len(ACTIONS))
        self.global_sum=np.zeros(len(ACTIONS))
        self.global_sq=np.zeros(len(ACTIONS))
        self.recent=[deque() for _ in ACTIONS]
        # Store *forecast at ghost creation*, then grade it after full maturity.
        self.fc_n=np.zeros(len(ACTIONS));self.fc_err=np.zeros(len(ACTIONS))
        self.fc_errsq=np.zeros(len(ACTIONS));self.fc_fast=np.zeros(len(ACTIONS))
        self.fc_slow=np.zeros(len(ACTIONS));self.fc_fast_n=np.zeros(len(ACTIONS))
        self.drift=np.zeros(len(ACTIONS));self.drifts_triggered=np.zeros(len(ACTIONS),dtype=int)
        self.total_labels=0;self.last_ts=0;self.active_day=0
        self.processed={};self.history=[]
    def signature(self,x):
        return np.arange(MOTIFS)*2+(np.dot(np.asarray(x,dtype=float),self.W)>0).astype(int)
    def recent_stats(self,a,t):
        q=self.recent[a]
        while q and q[0][0]<t-14400:q.popleft()
        values=[v for tt,v in q if tt>=t-7200]
        if len(values)<8:return None
        return float(np.mean(values)),len(values)
    def forecast(self,a,x,t):
        n=self.global_n[a]
        if n<20:
            return {'expected':-5.,'lower':-999.,'uncertainty':999.,'n_eff':0.,'raw':-5.,'novelty':1.}
        global_mean=self.global_sum[a]/n
        inds=self.signature(x)
        means=[];sigmas=[];supports=[]
        for m in inds:
            c=self.count[m,a]
            # Bayesian-like shrinkage: latent patterns cannot monopolize score at low N.
            mu=(self.total[m,a]+40*global_mean)/(c+40)
            means.append(mu)
            supports.append(c)
        raw=.45*global_mean+.55*float(np.mean(means))
        recent=self.recent_stats(a,t)
        if recent is not None: raw=.7*raw+.3*recent[0]
        bias=self.fc_err[a]/max(1.,self.fc_n[a])
        # Bias correction uses forecasts made BEFORE their outcomes were known.
        pred=raw+.65*bias*min(1.,self.fc_n[a]/35)
        global_var=max(400.,self.global_sq[a]/n-global_mean**2)
        _,_,_,_,h,stride=ACTIONS[a]
        # Overlapping ghosts create dependent labels. Treat at most stride/h as independent.
        eff=max(1.,n*min(1.,stride/h))
        neff=min(eff, min(supports)*min(1.,stride/h)+5)
        # Prequential forecast error is a crucial calibration diagnostic.
        rmse=math.sqrt(max(global_var,self.fc_errsq[a]/max(1.,self.fc_n[a])))
        unc=rmse/math.sqrt(neff+1)
        familiarity=min(supports)/max(1,n)
        novelty=float(max(0.,1-min(1.,familiarity*2)))
        # Conservative bound: guard against bias, statistical noise, strategy search and drift.
        margin=1.5*unc+4.*self.drift[a]+.16*rmse+6*novelty
        return {'expected':pred,'lower':pred-margin,'uncertainty':unc,'n_eff':neff,
                'raw':raw,'novelty':novelty,'rmse':rmse,'bias':bias}
    def observe(self,a,x,y,t,day_index,forecast_before):
        y=float(y);a=int(a);self.total_labels+=1;self.last_ts=t
        i=self.signature(x)
        self.count[i,a]+=1
        self.total[i,a]+=y
        self.squares[i,a]+=y*y
        self.daymask[i,a]|=np.uint32(1<<day_index)
        self.global_n[a]+=1;self.global_sum[a]+=y;self.global_sq[a]+=y*y
        q=self.recent[a];q.append((int(t),y))
        while q and q[0][0]<t-14400:q.popleft()
        if forecast_before is not None:
            e=float(np.clip(y-forecast_before,-400,400))
            self.fc_n[a]+=1;self.fc_err[a]+=e;self.fc_errsq[a]+=e*e
            # Compare fast vs slow, scale by observed forecast error to detect transitions.
            self.fc_fast[a]=.94*self.fc_fast[a]+.06*e
            self.fc_slow[a]=.995*self.fc_slow[a]+.005*e
            self.fc_fast_n[a]+=1
            scale=math.sqrt(max(400,self.fc_errsq[a]/self.fc_n[a]))
            drift_level=max(0.,(abs(self.fc_fast[a]-self.fc_slow[a])/scale-.22))*3
            prior=self.drift[a]
            self.drift[a]=.8*prior+.2*drift_level
            if self.drift[a]>.5 and prior<=.5:self.drifts_triggered[a]+=1
    def choose(self,x,t):
        forecasts=[self.forecast(a,x,t) for a in range(len(ACTIONS))]
        valid=[(a,p) for a,p in enumerate(forecasts) if p['n_eff']>=10 and self.fc_n[a]>=20 and
               self.drift[a]<1.0 and p['lower']>0]
        best=max(valid,key=lambda z:z[1]['lower']) if valid else None
        return (-1 if best is None else int(best[0])),forecasts
    def ideas(self,minimum_effective=10):
        """Mine spontaneous latent pattern-action candidates. Research only: unvalidated."""
        candidates=[]
        for a in range(len(ACTIONS)):
            _,_,_,_,h,stride=ACTIONS[a]; factor=min(1.,stride/h)
            for k in range(MOTIFS*2):
                n=self.count[k,a];eff=n*factor
                days=int(int(self.daymask[k,a]).bit_count())
                if eff<minimum_effective or days<3:continue
                mean=self.total[k,a]/n
                var=max(0.,self.squares[k,a]/n-mean**2)
                # Large multiple-testing penalty: a discovered pattern is not validated alpha.
                lower=mean-2.8*math.sqrt(max(var,400.)/max(1.,eff))
                candidates.append({'action':action_label(a),'motif':int(k),'sample_count':int(n),
                    'effective_count':round(float(eff),2),'distinct_development_days':days,
                    'mean_net':round(float(mean),2),'search_adjusted_lower':round(float(lower),2),
                    'positive_provisional':bool(lower>0)})
        return sorted(candidates,key=lambda z:z['search_adjusted_lower'],reverse=True)[:40]
    def state(self):
        obj={'schema':SCHEMA,'dim':self.dim,'projection_sha256':hashlib.sha256(self.W.tobytes()).hexdigest(),
             'processed':self.processed,'history':self.history,'total_labels':self.total_labels,
             'last_ts':self.last_ts,'active_day':self.active_day,
             'count':self.count.tolist(),'total':self.total.tolist(),'squares':self.squares.tolist(),
             'daymask':self.daymask.astype(int).tolist(),
             'global_n':self.global_n.tolist(),'global_sum':self.global_sum.tolist(),'global_sq':self.global_sq.tolist(),
             'fc_n':self.fc_n.tolist(),'fc_err':self.fc_err.tolist(),'fc_errsq':self.fc_errsq.tolist(),
             'fc_fast':self.fc_fast.tolist(),'fc_slow':self.fc_slow.tolist(),
             'fc_fast_n':self.fc_fast_n.tolist(),'drift':self.drift.tolist(),
             'drifts_triggered':self.drifts_triggered.tolist(),
             'recent':[[[int(t),float(y)] for t,y in q] for q in self.recent]}
        return obj
    @classmethod
    def restore(cls,obj):
        if obj.get('schema')!=SCHEMA:raise ValueError('Checkpoint schema mismatch')
        p=cls(int(obj['dim']))
        if obj.get('projection_sha256')!=hashlib.sha256(p.W.tobytes()).hexdigest():
            raise ValueError('Checkpoint feature projection fingerprint mismatch')
        for name in ('count','total','squares','daymask','global_n','global_sum','global_sq',
          'fc_n','fc_err','fc_errsq','fc_fast','fc_slow','fc_fast_n','drift','drifts_triggered'):
            arr=getattr(p,name);src=np.asarray(obj[name],dtype=arr.dtype)
            if src.shape!=arr.shape:raise ValueError('Checkpoint shape mismatch: '+name)
            setattr(p,name,src)
        p.recent=[deque((int(t),float(v)) for t,v in values) for values in obj['recent']]
        p.processed=dict(obj['processed']);p.history=list(obj['history'])
        p.total_labels=int(obj['total_labels']);p.last_ts=int(obj['last_ts']);p.active_day=int(obj['active_day'])
        return p

def run_v6_day(brain,d,date,day_index,cost=3.,decision_spacing_bars=6,max_decisions=None):
    from heapq import heappush,heappop
    X=encode(d);T=ghost_surface(d,cost=cost)
    n=len(d);ts=d.ts.to_numpy(np.int64)
    events=[];preds=[];trades=[];hyp=[];next_free=0;trained=0;checked=0
    for i in range(n):
        t=int(ts[i]+BAR)
        while events and events[0][0]<=i:
            maturity,a,j,fore=heappop(events)
            val=T[a].reward[j]
            if np.isfinite(val):
                brain.observe(a,X[j],val,t,day_index,fore);trained+=1
        for a,(_side,_name,_tp,_sl,h,stride) in enumerate(ACTIONS):
            if i%stride==0 and i+h<n:
                fore=brain.forecast(a,X[i],t)['expected']
                heappush(events,(i+h,a,i,fore))
        if i%decision_spacing_bars!=0 or i+1>=n:continue
        local=pd.Timestamp(int(ts[i+1]),unit='s',tz='UTC').tz_convert('America/New_York')
        if local.date().isoformat()!=date or not (0<=local.hour<15):continue
        if i<next_free:continue
        choice,forecasts=brain.choose(X[i],t)
        selected=choice>=0 and np.isfinite(T[choice].reward[i])
        if not selected:choice=-1
        best=max(forecasts,key=lambda z:z['lower'])
        p=forecasts[choice] if selected else best
        row={'date':date,'signal_ts':int(ts[i]),'action':choice,
             'action_name':action_label(choice) if selected else 'NO_TRADE',
             'model_expected':round(float(p['expected']),3),
             'model_lower':round(float(p['lower']),3),
             'model_uncertainty':round(float(p['uncertainty']),3),
             'effective_labels':round(float(p['n_eff']),1),
             'predicted_bias':round(float(p.get('bias',0)),2),
             'drift_score':round(float(brain.drift[choice] if selected else np.max(brain.drift)),3),
             'active_motifs':','.join(map(str,brain.signature(X[i]))),
             'action_scores':json.dumps({action_label(a):round(float(z['lower']),2) for a,z in enumerate(forecasts)})}
        if selected:
            tr=T[choice];e=int(tr.exit_i[i]);next_free=e+1
            row.update({'entry_ts':int(ts[i+1]),'exit_ts':int(ts[e]+5),
                        'entry_price':float(d.x_open.iat[i+1]),'exit_reason':int(tr.reason[i]),
                        'ambiguous_same_bar':bool(tr.ambiguous[i]),
                        'net_points':float(tr.reward[i]),'gross_points':float(tr.reward[i]+cost),
                        'mfe_points':float(tr.mfe[i]),'mae_points':float(tr.mae[i])})
            trades.append(row)
        if i%12==0 or selected:preds.append(row.copy())
        checked+=1
        if max_decisions and checked>=max_decisions:break
    summary={'date':date,'net_points':round(float(sum(r['net_points'] for r in trades)),2),
       'trade_count':len(trades),'win_count':sum(r['net_points']>0 for r in trades),
       'matured_ghosts':trained,'total_matured_labels':brain.total_labels,
       'novel_motifs':int(np.sum(brain.count.sum(axis=1)>0)),
       'drift_events':int(brain.drifts_triggered.sum()),'abstention_decisions':checked-len(trades),
       'decision_count':checked}
    return summary,pd.DataFrame(trades),pd.DataFrame(preds)
