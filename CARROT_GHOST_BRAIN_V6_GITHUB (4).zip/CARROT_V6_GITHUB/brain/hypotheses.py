"""Optional *research-only* local LLM; cannot edit code, risk rules or trade orders.

The LLM interprets aggregates from completed *development* paper ledgers and proposes
natural-language explanations plus experimental hypotheses. It does not set live signals.
"""
import json,sys,urllib.request
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'results'

def observe():
    # Every input comes from local development results, never holdout.
    files=sorted(DATA.glob('*_PAPER_TRADES.csv'))
    frames=[pd.read_csv(p) for p in files]
    if not frames:return {'status':'no_completed_paper_trades'}
    d=pd.concat(frames,ignore_index=True)
    out={'trades':int(len(d)),'total_net':round(float(d.net_points.sum()),2),
         'by_action':d.groupby('action_name').net_points.agg(['count','mean','sum']).round(2).to_dict('index'),
         'by_pattern':d.groupby('pattern_id').net_points.agg(['count','mean','sum']).round(2).to_dict('index'),
         'by_day':d.groupby('date').net_points.agg(['count','sum']).round(2).to_dict('index'),
         'worst_10_losses':d.nsmallest(10,'net_points')[['date','action_name','pattern_id','model_expected','novelty','drift','net_points']].round(2).to_dict('records')}
    return out

def ask_ollama(model='qwen2.5:7b'):
    payload=observe()
    prompt=('You are a RESEARCH HYPOTHESIS ANALYST, NOT AN ORDER EXECUTOR. '
      'Examine this development-only CARROT ghost trading evidence. Market patterns may differ '
      'radically. Suggest up to three testable hypotheses about market regimes, sequence motifs '
      'and payoff changes. For each give rationale, observable data needed, a causal experimental '
      'design, likely failure, and a negative-control test. Do not set live parameters or promise profit. '
      'Return JSON object with hypotheses array only. Evidence:\n'+json.dumps(payload)[:22000])
    body=json.dumps({'model':model,'stream':False,'format':'json',
                     'messages':[{'role':'user','content':prompt}]}).encode('utf-8')
    request=urllib.request.Request('http://127.0.0.1:11434/api/chat',data=body,
             headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(request,timeout=120) as r:raw=json.load(r)
    proposal=json.loads(raw['message']['content'])
    if not isinstance(proposal,dict) or not isinstance(proposal.get('hypotheses'),list):
        raise ValueError('Invalid LLM hypothesis format')
    DATA.mkdir(exist_ok=True)
    (DATA/'LLM_HYPOTHESES_RESEARCH_ONLY.json').write_text(json.dumps({'model':model,
      'development_evidence':payload,'proposals':proposal,
      'not_for_execution':True},indent=2),encoding='utf8')
    return proposal

if __name__=='__main__':
    try:print(json.dumps(ask_ollama(sys.argv[1] if len(sys.argv)>1 else 'qwen2.5:7b'),indent=2))
    except Exception as e:print('Ollama unavailable or invalid reply:',e);sys.exit(1)
