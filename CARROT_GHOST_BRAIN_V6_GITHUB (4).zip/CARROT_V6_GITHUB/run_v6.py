"""V6 historical CAUSAL replay and forward-only persistent cloud research memory.
Never replays an already processed date into a restored checkpoint.
For clean head-to-head comparisons run with --fresh and a separate output directory.
"""
import argparse,hashlib,json,os,time
from pathlib import Path
import pandas as pd
from brain.core import LOCKED,encode,load_day
from brain.v6 import GhostResearchBrain,run_v6_day
ROOT=Path(__file__).resolve().parent

def atomic_json(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf8')
    tmp.replace(path)

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def run(args):
    out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
    paths=sorted((ROOT/'data'/'5s_features').glob('*_5s_features.csv'))
    if len(paths)!=20 or any(x.name[:10] in LOCKED for x in paths):
        raise RuntimeError('Development firewall: require exactly 20 permitted day files')
    state=Path(args.state).resolve() if args.state else None
    if args.fresh and state and state.exists():raise ValueError('--fresh requires a new unused checkpoint path')
    brain=GhostResearchBrain(encode(load_day(paths[0])[1]).shape[1])
    if state and state.exists() and not args.fresh:
        brain=GhostResearchBrain.restore(json.loads(state.read_text()))
        print('RESTORED CHECKPOINT: labels',brain.total_labels,'dates',len(brain.processed),flush=True)
    current={p.name[:10]:sha(p) for p in paths}
    if any(d not in current or current[d]!=digest for d,digest in brain.processed.items()):
        raise RuntimeError('A processed dataset was removed or changed; refusing double-train/invalid resume.')
    ordered=list(current)
    done=list(brain.processed)
    if done and done!=ordered[:len(done)]:
        raise RuntimeError('New older-dated data breaks chronological forward-only replay; use fresh research.')
    pending=[p for p in paths if p.name[:10] not in brain.processed]
    if not pending:print('NO NEW DATES: checkpoint restored. Historical days NOT trained a second time.',flush=True)
    for p in pending:
        date,df=load_day(p)
        started=time.monotonic()
        result,trades,decisions=run_v6_day(brain,df,date,ordered.index(date),args.cost)
        result['runtime_sec']=round(time.monotonic()-started,2)
        result['hypothetical_cost']=args.cost
        result['dev_file_sha256']=current[date]
        brain.processed[date]=current[date]
        brain.history.append(result)
        if len(trades):trades.to_csv(out/(date+'_V6_PAPER_TRADES.csv'),index=False)
        decisions.to_csv(out/(date+'_V6_DECISIONS.csv'),index=False)
        if state:atomic_json(state,brain.state())
        print('DAY',json.dumps(result),flush=True)
    history=pd.DataFrame(brain.history)
    history.to_csv(out/'V6_DAY_BY_DAY.csv',index=False)
    total=float(history.net_points.sum()) if len(history) else 0.
    score={'model':'V6 latent motif prequential ghost researcher','date_count':len(history),
      'sum_net_points':total,'daily_mean':float(history.net_points.mean()) if len(history) else 0.,
      'losing_days':int((history.net_points<0).sum()) if len(history) else 0,
      'worst_day':float(history.net_points.min()) if len(history) else 0.,
      'trades':int(history.trade_count.sum()) if len(history) else 0,
      'labeled_ghosts':int(brain.total_labels),'restored_days':len(done),'new_days':len(pending),
      'hypothetical_cost_points':args.cost,'locked_dates_not_loaded':sorted(LOCKED),
      'checkpoint_sha256':sha(state) if state else None,
      'disclaimer':'DEVELOPMENT ONLY. Zero trades can yield zero loss without generating profit. Not independent holdout, not realistic tick fills or live-capable.'}
    atomic_json(out/'V6_SCORECARD.json',score)
    ideas=brain.ideas()
    atomic_json(out/'V6_UNVALIDATED_MOTIF_IDEAS.json',{
      'warning':'Motif mining results are discovered IN SAMPLE and NOT proven tradable. Treat as proposed hypotheses, not accepted strategies.',
      'patterns':ideas,'count':len(ideas)})
    print('SCORECARD',json.dumps(score),flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--cost',type=float,default=3.)
    a.add_argument('--state',default='',help='Optional checkpoint JSON; resume processes NEW later dates only')
    a.add_argument('--output',default=str(ROOT/'results_v6'))
    a.add_argument('--fresh',action='store_true')
    run(a.parse_args())
