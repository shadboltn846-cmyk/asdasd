# CARROT V6 Ghost Brain — Research Candidate (NOT LIVE)

This is a replacement **research pipeline** for V5. It is not yet a profitable or validated trading system and it cannot reason like a general-purpose LLM.

## What it implements

- Two virtual directions across four exit plans on every five-second completed market bar (`brain/core.py:ghost_surface`).
- Market features include short-term to multi-hour price movement, GC delta, aggression, book vacuum, absorption, relative range position and normalized temporal patches.
- 24 sparse multivariate random projections representing 48 learned latent motifs. These are numerical market-state fingerprints, not human-named patterns or newly invented order types.
- Outcome training **only after the full ghost horizon is over**. New future outcomes cannot change earlier predictions.
- Prequential prediction-error measurement: record the estimate at ghost launch; compare it with the subsequently matured result, correcting bias.
- Conservative uncertainty estimates that discount overlapping ghosts by their training-stride-to-horizon ratio; no assumption that thousands of ghosts are independent trades.
- Drift monitor based on changes in short/long forecast residual averages. Novelty and excessive drift block decisions.
- Explicit NO TRADE, paper-only execution, one position at a time, stop-first handling of OHLC TP/SL ambiguity, assumed transaction costs.
- Automatically discovered action/motif hypotheses with broad multiple-search uncertainty penalties; they are research proposals, not deployable strategies.
- Separate `research_loop_v6.py` runs one new numerical pattern representation per cloud run and freezes research ideas on the first **14** development dates before checking on the last **six**. This is an **internal development forward check**, *not a true blind holdout*.
- JSON checkpoint and experiment journal restored/saved between GitHub runs with Actions cache; a repeat run never retrains the same historical dates a second time.
- 12-experiment cap to limit overfitting from repeatedly searching the same 20 known dates.

## Historical research already executed on 20 DEVELOPMENT days

| Candidate | Net points/day | Negative days | Worst day | Paper trades |
|---|---:|---:|---:|---:|
| V5 cloud reference | -76.99 | 12/20 | -523.60 | 202 |
| V6 initial latent-motif policy | -70.13 | 10/20 | -439.20 | 44 |

Note: fewer trades and a slightly less-negative average are not profitability or an improvement over original V4. Earlier V4 development-only baseline was approximately **+114.51 net/day**. The seven locked dates were never loaded in V6 runs.

An additional motif-representation experiment (seed=297, before deploying cloud workflow) averaged -59.09 net/day across 20 development dates and lost -335.20 points across the last six internal development days. It was **not promoted**.

## Seven dates explicitly excluded

2026-03-03, 2026-03-06, 2026-04-14, 2026-04-17, 2026-06-10, 2026-06-16, 2026-08-24.

The source ZIP contains only the 20 permitted development datasets. The reserved dates may have been seen during older research; this package does not re-read or re-score them.

## GitHub easy setup (existing private Trading repository)

1. Add `CARROT_GHOST_BRAIN_V6_GITHUB.zip` **as a file** at the root of your GitHub repository. No need to extract it or re-upload the 20 individual CSVs.
2. Edit the existing `.github/workflows/carrot_research.yml` on GitHub. Replace its contents with `carrot_v6_research.yml` supplied separately.
3. Commit both changes to the `main` branch.
4. Go to **Actions → CARROT V6 Ghost Brain Autonomous Research → Run workflow**.
5. Download artifact `carrot-v6-research-#` and share it for analysis.

When the ZIP is changed to a new code version, restoring old checkpoints may be incompatible. Do not use checkpoints as a way to validate trades on already scored dates. `--fresh` is for separate clean comparison replays, not for blindly accumulating another backtest.

The GitHub workflow cannot automatically ingest live Databento/MT5 feeds. Running it again on the same 20 historical dates produces one new bounded motif experiment and does not magically create new market data. A truly always-on AI brain requires a persistent feed/server and extensive unseen forward paper testing. GitHub cache may be evicted; each artifact includes a downloadable checkpoint backup.

## Local CLI (optional; GitHub does this automatically)

```bash
python -m pip install -r requirements.txt
python tests/test_brain.py
python tests/test_v6.py
python run_v6.py --cost 3 --state state/ghost_memory.json --output results_v6
python research_loop_v6.py --state-dir state --output results_v6 --cost 3
```

**No order sending, live brokerage connection, financial guarantee, or access to protected data is provided.**
